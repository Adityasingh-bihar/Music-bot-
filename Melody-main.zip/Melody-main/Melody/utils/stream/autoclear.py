import os
import gc

from config import autoclean

async def auto_clean(popped):
    try:
        rem = popped["file"]
        autoclean.remove(rem)
        count = autoclean.count(rem)
        if count == 0:
            if "vid_" not in rem or "live_" not in rem or "index_" not in rem:
                if rem.startswith("http"):
                    return
                try:
                    os.remove(rem)
                    gc.collect()
                except:
                    pass
    except:
        pass
